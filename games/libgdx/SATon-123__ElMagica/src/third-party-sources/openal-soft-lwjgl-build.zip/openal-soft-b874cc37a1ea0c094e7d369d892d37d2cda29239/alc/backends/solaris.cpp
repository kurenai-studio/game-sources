/**
 * OpenAL cross platform audio library
 * Copyright (C) 1999-2007 by authors.
 * This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 *  License along with this library; if not, write to the
 *  Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 * Or go to http://www.gnu.org/copyleft/lgpl.html
 */

#include "config.h"

#include "solaris.h"

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <math.h>
#include <string.h>
#include <vector>

#include <span>
#include <thread>
#include <functional>

#include "alc/alconfig.h"
#include "alstring.h"
#include "althrd_setname.h"
#include "core/device.h"
#include "core/helpers.h"
#include "gsl/gsl"

#include <sys/audioio.h>

#if HAVE_CXXMODULES
import logging;
#else
#include "core/logging.h"
#endif


namespace {

using namespace std::string_view_literals;

[[nodiscard]] constexpr auto GetDefaultName() noexcept { return "Solaris Default"sv; }

std::string solaris_driver{"/dev/audio"};


struct SolarisBackend final : BackendBase {
    explicit SolarisBackend(gsl::not_null<DeviceBase*> const device) noexcept : BackendBase{device}
    { }
    ~SolarisBackend() override;

    int mixerProc();

    void open(std::string_view name) override;
    bool reset() override;
    void start() override;
    void stop() override;

    int mFd{-1};

    unsigned mFrameStep{};
    std::vector<std::byte> mBuffer;

    std::atomic<bool> mKillNow{true};
    std::thread mThread;
};

SolarisBackend::~SolarisBackend()
{
    if(mFd != -1)
        close(mFd);
    mFd = -1;
}

int SolarisBackend::mixerProc()
{
    SetRTPriority();
    althrd_setname(GetMixerThreadName());

    auto const frame_step = std::size_t{mDevice->channelsFromFmt()};
    auto const frame_size = std::size_t{mDevice->frameSizeFromFmt()};

    while(!mKillNow.load(std::memory_order_acquire)
        && mDevice->Connected.load(std::memory_order_acquire))
    {
        auto pollitem = pollfd{};
        pollitem.fd = mFd;
        pollitem.events = POLLOUT;

        if(auto const pret = poll(&pollitem, 1, 1000); pret < 0)
        {
            if(errno == EINTR || errno == EAGAIN)
                continue;
            ERR("poll failed: {}", strerror(errno));
            mDevice->handleDisconnect("Failed to wait for playback buffer: {}", strerror(errno));
            break;
        }
        else if(pret == 0)
        {
            WARN("poll timeout");
            continue;
        }

        auto buffer = std::span{mBuffer};
        mDevice->renderSamples(buffer.data(), gsl::narrow_cast<unsigned>(buffer.size()/frame_size),
            frame_step);
        while(!buffer.empty() && !mKillNow.load(std::memory_order_acquire))
        {
            auto const wrote = write(mFd, buffer.data(), buffer.size());
            if(wrote < 0)
            {
                if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)
                    continue;
                ERR("write failed: {}", strerror(errno));
                mDevice->handleDisconnect("Failed to write playback samples: {}", strerror(errno));
                break;
            }

            buffer = buffer.subspan(gsl::narrow<std::size_t>(wrote));
        }
    }

    return 0;
}


void SolarisBackend::open(std::string_view name)
{
    if(name.empty())
        name = GetDefaultName();
    else if(name != GetDefaultName())
        throw al::backend_exception{al::backend_error::NoDevice, "Device name \"{}\" not found",
            name};

    int fd{::open(solaris_driver.c_str(), O_WRONLY)};
    if(fd == -1)
        throw al::backend_exception{al::backend_error::NoDevice, "Could not open {}: {}",
            solaris_driver, strerror(errno)};

    if(mFd != -1)
        ::close(mFd);
    mFd = fd;

    mDeviceName = name;
}

bool SolarisBackend::reset()
{
    audio_info_t info;
    AUDIO_INITINFO(&info);

    info.play.sample_rate = mDevice->mSampleRate;
    info.play.channels = mDevice->channelsFromFmt();
    switch(mDevice->FmtType)
    {
    case DevFmtByte:
        info.play.precision = 8;
        info.play.encoding = AUDIO_ENCODING_LINEAR;
        break;
    case DevFmtUByte:
        info.play.precision = 8;
        info.play.encoding = AUDIO_ENCODING_LINEAR8;
        break;
    case DevFmtUShort:
    case DevFmtInt:
    case DevFmtUInt:
    case DevFmtFloat:
        mDevice->FmtType = DevFmtShort;
        [[fallthrough]];
    case DevFmtShort:
        info.play.precision = 16;
        info.play.encoding = AUDIO_ENCODING_LINEAR;
        break;
    }
    info.play.buffer_size = mDevice->mBufferSize * mDevice->frameSizeFromFmt();

    if(ioctl(mFd, AUDIO_SETINFO, &info) < 0)
    {
        ERR("ioctl failed: {}", strerror(errno));
        return false;
    }

    if(mDevice->channelsFromFmt() != info.play.channels)
    {
        if(info.play.channels >= 2)
            mDevice->FmtChans = DevFmtStereo;
        else if(info.play.channels == 1)
            mDevice->FmtChans = DevFmtMono;
        else
            throw al::backend_exception{al::backend_error::DeviceError,
                "Got {} device channels", info.play.channels};
    }

    if(info.play.precision == 8 && info.play.encoding == AUDIO_ENCODING_LINEAR8)
        mDevice->FmtType = DevFmtUByte;
    else if(info.play.precision == 8 && info.play.encoding == AUDIO_ENCODING_LINEAR)
        mDevice->FmtType = DevFmtByte;
    else if(info.play.precision == 16 && info.play.encoding == AUDIO_ENCODING_LINEAR)
        mDevice->FmtType = DevFmtShort;
    else if(info.play.precision == 32 && info.play.encoding == AUDIO_ENCODING_LINEAR)
        mDevice->FmtType = DevFmtInt;
    else
    {
        ERR("Got unhandled sample type: {} ({:#x})", info.play.precision, info.play.encoding);
        return false;
    }

    auto const frame_size = unsigned{mDevice->bytesFromFmt() * info.play.channels};
    mFrameStep = info.play.channels;
    mDevice->mSampleRate = info.play.sample_rate;
    mDevice->mBufferSize = info.play.buffer_size / frame_size;
    /* How to get the actual period size/count? */
    mDevice->mUpdateSize = mDevice->mBufferSize / 2;

    setDefaultChannelOrder();

    mBuffer.resize(mDevice->mUpdateSize * std::size_t{frame_size});
    std::ranges::fill(mBuffer, std::byte{});

    return true;
}

void SolarisBackend::start()
{
    try {
        mKillNow.store(false, std::memory_order_release);
        mThread = std::thread{&SolarisBackend::mixerProc, this};
    }
    catch(std::exception& e) {
        throw al::backend_exception{al::backend_error::DeviceError,
            "Failed to start mixing thread: {}", e.what()};
    }
}

void SolarisBackend::stop()
{
    if(mKillNow.exchange(true, std::memory_order_acq_rel) || !mThread.joinable())
        return;
    mThread.join();

    if(ioctl(mFd, AUDIO_DRAIN) < 0)
        ERR("Error draining device: {}", strerror(errno));
}

} // namespace

auto SolarisBackendFactory::getFactory() -> BackendFactory &
{
    static SolarisBackendFactory factory{};
    return factory;
}

auto SolarisBackendFactory::init() -> bool
{
    if(auto devopt = ConfigValueStr({}, "solaris", "device"))
        solaris_driver = std::move(*devopt);
    return true;
}

auto SolarisBackendFactory::querySupport(BackendType const type) -> bool
{ return type == BackendType::Playback; }

auto SolarisBackendFactory::enumerate(BackendType const type) -> std::vector<std::string>
{
    switch(type)
    {
    case BackendType::Playback:
        if(struct stat buf{}; stat(solaris_driver.c_str(), &buf) == 0)
            return std::vector{std::string{GetDefaultName()}};
        break;

    case BackendType::Capture:
        break;
    }
    return {};
}

auto SolarisBackendFactory::createBackend(gsl::not_null<DeviceBase*> const device,
    BackendType const type) -> BackendPtr
{
    if(type == BackendType::Playback)
        return BackendPtr{new SolarisBackend{device}};
    return nullptr;
}
